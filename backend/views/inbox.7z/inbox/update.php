<?php
use yii\helpers\Html;

?>
<div class="inbox-update">

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
